-- Adicionar tipo 'sendflow' ao enum whatsapp_template_type
ALTER TYPE whatsapp_template_type ADD VALUE IF NOT EXISTS 'sendflow';