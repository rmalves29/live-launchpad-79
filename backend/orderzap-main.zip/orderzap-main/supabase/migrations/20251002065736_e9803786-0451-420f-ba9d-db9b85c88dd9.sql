-- Adicionar o valor 'item_added' ao enum whatsapp_message_type
ALTER TYPE whatsapp_message_type ADD VALUE IF NOT EXISTS 'item_added';