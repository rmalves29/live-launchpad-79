-- Testar o trigger para todas as empresas - pedido da BIQUINI DA TAHY
UPDATE public.orders SET is_paid = true WHERE id = 4;