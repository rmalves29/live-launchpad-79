-- Atualizar o perfil do usuário para vincular à empresa thaybiquini
UPDATE profiles 
SET tenant_id = 'a5bda88f-11ec-4043-85b7-6ba242821119'
WHERE email = 'rmalves21@hotmail.com';