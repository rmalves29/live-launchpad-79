-- Update order 32 to mark it as paid
UPDATE orders SET is_paid = true WHERE id = 32;