-- Adicionar campo instagram na tabela customers
ALTER TABLE customers ADD COLUMN instagram text;