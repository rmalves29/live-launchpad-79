-- Adicionar campo email na tabela customers
ALTER TABLE public.customers ADD COLUMN email text;